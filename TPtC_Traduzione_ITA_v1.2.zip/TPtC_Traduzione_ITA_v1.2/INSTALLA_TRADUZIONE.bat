@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  Traduzione italiana - The Procession to Calvary
echo ============================================================
echo.
echo Chiudi il gioco prima di continuare.
echo.
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython

echo Controllo UnityPy...
%PY% -m pip install --quiet "UnityPy==1.25.4"
if errorlevel 1 goto errpip

%PY% patcher\applica_traduzione.py
echo.
pause
exit /b 0

:nopython
echo Python non trovato.
echo Installalo da https://www.python.org/downloads/ e durante l'installazione
echo spunta "Add python.exe to PATH". Poi rilancia questo file.
echo.
pause
exit /b 1

:errpip
echo Errore nell'installazione di UnityPy. Controlla la connessione a Internet.
echo.
pause
exit /b 1

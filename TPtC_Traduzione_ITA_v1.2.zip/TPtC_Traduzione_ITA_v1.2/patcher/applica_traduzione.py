# -*- coding: utf-8 -*-
"""
Traduzione italiana di "The Procession to Calvary" - patcher.

Applica la traduzione ai file del TUO gioco installato. Non contiene file del gioco:
legge i tuoi file originali, sostituisce solo i testi e riscrive i file.

Uso:
    python applica_traduzione.py                 (cerca il gioco da solo oppure te lo chiede)
    python applica_traduzione.py --gioco "C:\\...\\The Procession to Calvary"
    python applica_traduzione.py --prova         (simulazione: non scrive nulla)
    python applica_traduzione.py --ripristina    (rimette i file originali)
"""
import argparse
import inspect
import json
import os
import shutil
import struct
import sys
import textwrap
import zlib

QUI = os.path.dirname(os.path.abspath(__file__))
DATI = os.path.join(QUI, 'dati', 'traduzione.json')
NOME_DATA = 'The Procession to Calvary_Data'
NOME_BACKUP = 'Backup_originali_ITA'
POSSIBILI = [
    r'C:\Program Files (x86)\Steam\steamapps\common\The Procession to Calvary',
    r'C:\Program Files\Steam\steamapps\common\The Procession to Calvary',
    r'D:\SteamLibrary\steamapps\common\The Procession to Calvary',
    r'E:\SteamLibrary\steamapps\common\The Procession to Calvary',
]


def trova_gioco(arg):
    cand = [arg] if arg else []
    cand += POSSIBILI
    for c in cand:
        if c and os.path.isdir(os.path.join(c, NOME_DATA)):
            return c
        if c and os.path.basename(c.rstrip('\\/')) == NOME_DATA and os.path.isdir(c):
            return os.path.dirname(c.rstrip('\\/'))
    print('Non trovo la cartella del gioco.')
    p = input('Incolla qui il percorso della cartella "The Procession to Calvary": ').strip().strip('"')
    if os.path.isdir(os.path.join(p, NOME_DATA)):
        return p
    print('Cartella non valida.')
    sys.exit(1)


def patch_unitypy():
    """UnityPy allinea gli oggetti a 8 byte, Unity 6 a 16: riallineiamo per ottenere file identici in struttura."""
    import UnityPy.files  # noqa: F401
    from UnityPy.files import SerializedFile
    from typing import Optional
    mod = sys.modules['UnityPy.files.SerializedFile']
    src = textwrap.dedent(inspect.getsource(SerializedFile.save))
    vecchio = "obj.write(header, meta_writer, data_writer)\n        data_writer.align_stream(8)"
    if vecchio not in src:
        print('Versione di UnityPy non compatibile. Installa: pip install UnityPy==1.25.4')
        sys.exit(1)
    src = src.replace(vecchio, "data_writer.align_stream(16)\n        obj.write(header, meta_writer, data_writer)")
    ns = dict(vars(mod))
    ns['Optional'] = Optional
    exec(src, ns)
    SerializedFile.save = ns['save']


def scansiona(raw):
    """Trova le stringhe 'lunghezza + testo' dentro i dati di un oggetto (stesso metodo usato per creare la traduzione)."""
    out = []
    i = 0
    L = len(raw)
    while i + 4 <= L:
        n = struct.unpack_from('<i', raw, i)[0]
        if 2 <= n <= 5000 and i + 4 + n <= L:
            try:
                s = raw[i + 4:i + 4 + n].decode('utf-8')
            except Exception:
                i += 4
                continue
            if all((c >= ' ' or c in '\n\t\r') for c in s):
                out.append((i, s))
                i += 4 + ((n + 3) & ~3)
                continue
        i += 4
    return out


def pad4(n):
    return (n + 3) & ~3


def applica_file(UnityPy, sorgente, destinazione, voci, scrivi):
    env = UnityPy.load(sorgente)
    ok = 0
    mancanti = 0
    for o in env.objects:
        chiave = str(o.path_id)
        if chiave not in voci:
            continue
        raw = bytearray(o.get_raw_data())
        stringhe = [(off, s) for off, s in scansiona(bytes(raw)) if off > 28]
        scelte = {}
        for crc, occ, nuovo in voci[chiave]:
            c = [(off, s) for off, s in stringhe if (zlib.crc32(s.encode('utf-8')) & 0xffffffff) == crc]
            if occ < len(c):
                scelte[c[occ][0]] = (c[occ][1], nuovo)
            else:
                mancanti += 1
        for off in sorted(scelte, reverse=True):
            vecchio, nuovo = scelte[off]
            n = struct.unpack_from('<i', raw, off)[0]
            nb = nuovo.encode('utf-8')
            fine = off + 4 + pad4(n)
            raw[off:fine] = struct.pack('<i', len(nb)) + nb + b'\x00' * (pad4(len(nb)) - len(nb))
            ok += 1
        o.set_raw_data(bytes(raw))
    totale = ok + mancanti
    if totale and mancanti / totale > 0.05:
        return ok, mancanti, False
    if scrivi:
        dati = env.file.save()
        tmp = destinazione + '.tmp'
        with open(tmp, 'wb') as f:
            f.write(dati)
        os.replace(tmp, destinazione)
    return ok, mancanti, True


def main():
    ap = argparse.ArgumentParser(description='Traduzione italiana di The Procession to Calvary')
    ap.add_argument('--gioco', help='cartella del gioco')
    ap.add_argument('--prova', action='store_true', help='simula senza scrivere')
    ap.add_argument('--ripristina', action='store_true', help='ripristina i file originali')
    a = ap.parse_args()

    gioco = trova_gioco(a.gioco)
    data = os.path.join(gioco, NOME_DATA)
    backup = os.path.join(gioco, NOME_BACKUP)
    print('Gioco trovato in:', gioco)

    with open(DATI, encoding='utf-8') as f:
        tr = json.load(f)
    file_tr = tr['file']

    if a.ripristina:
        if not os.path.isdir(backup):
            print('Nessun backup trovato: niente da ripristinare.')
            return
        for nome in os.listdir(backup):
            shutil.copy2(os.path.join(backup, nome), os.path.join(data, nome))
            print('ripristinato', nome)
        print('Fatto. Il gioco e\' tornato com\'era prima della traduzione.')
        return

    try:
        bi = open(os.path.join(gioco, 'buildinfo.txt'), encoding='utf-8', errors='replace').read(600)
        if 'Application Version: ' + tr['versione_gioco'] not in bi:
            print('ATTENZIONE: la versione del gioco non e\' la %s per cui e\' stata fatta la traduzione.' % tr['versione_gioco'])
            if input('Continuare lo stesso? (s/N) ').strip().lower() != 's':
                return
    except OSError:
        pass

    try:
        import UnityPy
    except ImportError:
        print('Manca UnityPy. Installalo con:  pip install UnityPy==1.25.4')
        sys.exit(1)
    patch_unitypy()

    if not a.prova:
        os.makedirs(backup, exist_ok=True)
    tot_ok = tot_man = 0
    saltati = []
    nomi = sorted(file_tr, key=lambda x: (not x.startswith('level'), int(''.join(c for c in x if c.isdigit()) or 0)))
    for i, nome in enumerate(nomi, 1):
        orig = os.path.join(data, nome)
        if not os.path.exists(orig):
            print('manca il file', nome)
            saltati.append(nome)
            continue
        copia = os.path.join(backup, nome)
        if not a.prova and not os.path.exists(copia):
            shutil.copy2(orig, copia)
        sorgente = copia if os.path.exists(copia) else orig
        ok, man, scritto = applica_file(UnityPy, sorgente, orig, file_tr[nome], not a.prova)
        tot_ok += ok
        tot_man += man
        stato = 'ok' if scritto else 'SALTATO (troppe differenze: versione diversa del gioco?)'
        if not scritto:
            saltati.append(nome)
        print('[%2d/%d] %-24s testi tradotti: %5d  non trovati: %d  %s' % (i, len(nomi), nome, ok, man, stato))
    print()
    print('Testi tradotti: %d   non trovati: %d' % (tot_ok, tot_man))
    if saltati:
        print('File non modificati:', ', '.join(saltati))
    if a.prova:
        print('(simulazione: non e\' stato scritto nulla)')
    else:
        print('Fatto! I file originali sono in:', backup)
        print('Avvia il gioco con la lingua inglese: i testi compariranno in italiano.')


if __name__ == '__main__':
    main()

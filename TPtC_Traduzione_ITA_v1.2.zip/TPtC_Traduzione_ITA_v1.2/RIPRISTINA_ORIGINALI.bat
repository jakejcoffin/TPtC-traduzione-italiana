@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  Ripristino dei file originali - The Procession to Calvary
echo ============================================================
echo.
echo Chiudi il gioco prima di continuare.
echo.
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python non trovato: in alternativa usa su Steam
  echo Proprieta - File installati - Verifica l'integrita dei file di gioco.
  pause
  exit /b 1
)
%PY% patcher\applica_traduzione.py --ripristina
echo.
pause
